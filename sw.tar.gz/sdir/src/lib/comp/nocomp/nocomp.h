#ifndef ZCHUNK_COMPRESSION_NOCOMP_H
#define ZCHUNK_COMPRESSION_NOCOMP_H

int nocomp_setup(zckCtx *zck, zckComp *comp);

#endif
