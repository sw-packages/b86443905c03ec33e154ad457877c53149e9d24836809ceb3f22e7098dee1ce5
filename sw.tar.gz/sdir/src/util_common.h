#ifndef UTIL_COMMON_H
#define UTIL_COMMON_H

#define ZCK_NAME "zchunk"
#define ZCK_COPYRIGHT_YEAR "2018"

#ifndef BUF_SIZE
#define BUF_SIZE 32768
#endif

void version();

#endif
